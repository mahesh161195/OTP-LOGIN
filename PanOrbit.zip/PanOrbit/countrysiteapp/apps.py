from django.apps import AppConfig


class CountrysiteappConfig(AppConfig):
    name = 'countrysiteapp'
