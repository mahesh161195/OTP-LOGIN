from django.contrib import admin

from countrysiteapp.models import country

# Register your models here.
class countryAdmin(admin.ModelAdmin):
    list_display=['name','details']


admin.site.register(country,countryAdmin)
